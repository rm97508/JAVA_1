package entrada_processamento_saida;

public class ex42 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
