package entrada_processamento_saida;

import java.util.Scanner;

public class ex37 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner ler = new Scanner (System.in);
		
		

	}

}
