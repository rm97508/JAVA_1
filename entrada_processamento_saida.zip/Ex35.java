package entrada_processamento_saida;

public class ex35 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
